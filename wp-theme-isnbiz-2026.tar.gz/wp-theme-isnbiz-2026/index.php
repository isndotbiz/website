<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @package ISNBIZ_2026
 * @since 1.0.0
 */

get_header(); ?>

<!-- WCAG FIX: Skip navigation link for keyboard users -->
<a href="#about" class="skip-link">Skip to main content</a>

<!-- Hero Section -->
<section class="hero">
    <div class="hero-background"></div>
    <div class="container hero-container">
        <div class="hero-content">
            <div class="hero-logo">
                <img src="https://isnbiz-assets-1769962280.s3.us-east-1.amazonaws.com/premium_v3/logos/hero_logo.webp" alt="iSN.BiZ Inc - Innovation Solutions Systems" class="hero-logo-img">
            </div>
            <h1 class="hero-title">Building the Future of Enterprise Software</h1>
            <p class="hero-subtitle">AI-Powered Solutions. Proven Results. Strategic Innovation.</p>
            <div class="hero-stats">
                <div class="stat">
                    <div class="stat-number">11+</div>
                    <div class="stat-label">Years Experience</div>
                </div>
                <div class="stat">
                    <div class="stat-number">Enterprise</div>
                    <div class="stat-label">Client Focus</div>
                </div>
                <div class="stat">
                    <div class="stat-number">100%</div>
                    <div class="stat-label">Client Retention</div>
                </div>
            </div>
            <div class="hero-cta">
                <a href="#investors" class="btn btn-primary"><span>Investment Opportunities</span></a>
                <a href="#contact" class="btn btn-secondary"><span>Schedule a Demo</span></a>
            </div>
            <div class="hero-visual">
                <img src="https://isnbiz-assets-1769962280.s3.us-east-1.amazonaws.com/premium_v3/services/ai_research.webp" alt="AI opportunity analytics dashboard mockup" loading="eager">
            </div>
        </div>
    </div>
    <div class="hero-scroll">
        <span>Scroll to explore</span>
        <div class="scroll-indicator"></div>
    </div>
</section>

<!-- Company Overview -->
<section id="about" class="section about">
    <div class="container">
        <div class="section-header">
            <span class="section-label">About iSN.BiZ</span>
            <h2 class="section-title">Transforming Ideas Into Powerful Software Solutions</h2>
        </div>
        <div class="about-grid">
            <div class="about-content">
                <p class="lead">Founded in 2015, iSN.BiZ Inc is a software design and development company focused on delivering cutting-edge solutions that drive business transformation.</p>
                <p>We specialize in creating custom software solutions that leverage the latest technologies, including artificial intelligence, cloud computing, and advanced data analytics. Our approach combines deep technical expertise with strategic business insight to deliver solutions that create measurable value.</p>
                <div class="about-highlights">
                    <div class="highlight-item">
                        <div class="highlight-icon">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                <polyline points="22 4 12 14.01 9 11.01"></polyline>
                            </svg>
                        </div>
                        <div class="highlight-text">
                            <h3>AI-Powered Innovation</h3>
                            <p>Integrating artificial intelligence to deliver 10x efficiency gains</p>
                        </div>
                    </div>
                    <div class="highlight-item">
                        <div class="highlight-icon">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                            </svg>
                        </div>
                        <div class="highlight-text">
                            <h3>Enterprise Grade</h3>
                            <p>Scalable, secure solutions built for mission-critical applications</p>
                        </div>
                    </div>
                    <div class="highlight-item">
                        <div class="highlight-icon">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>
                            </svg>
                        </div>
                        <div class="highlight-text">
                            <h3>Proven Track Record</h3>
                            <p>Delivering results since 2015 with 100% client retention</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="about-credentials">
                <div class="credential-card">
                    <h3>Company Information</h3>
                    <ul class="credential-list">
                        <li><strong>Founded:</strong> July 8, 2015</li>
                        <li><strong>DUNS:</strong> 080513772</li>
                        <li><strong>UBI:</strong> 603-522-339</li>
                        <li><strong>EIN:</strong> 47-4530188</li>
                        <li><strong>Focus:</strong> Software Design & Development</li>
                    </ul>
                </div>
                <div class="credential-card">
                    <h3>Core Competencies</h3>
                    <ul class="competency-list">
                        <li>AI & Machine Learning Integration</li>
                        <li>Cloud Architecture & DevOps</li>
                        <li>Custom Enterprise Software</li>
                        <li>Data Analytics & Business Intelligence</li>
                        <li>API Development & Integration</li>
                        <li>Cybersecurity Solutions</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Solutions Overview -->
<section id="solutions" class="section solutions">
    <div class="container">
        <div class="section-header centered">
            <span class="section-label">Our Solutions</span>
            <h2 class="section-title">Comprehensive Software Solutions for Modern Enterprises</h2>
            <p class="section-description">We deliver end-to-end software solutions that drive digital transformation and competitive advantage</p>
        </div>
        <div class="solutions-grid">
            <div class="solution-card">
                <div class="solution-icon">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                        <polyline points="7.5 4.21 12 6.81 16.5 4.21"></polyline>
                        <polyline points="7.5 19.79 7.5 14.6 3 12"></polyline>
                        <polyline points="21 12 16.5 14.6 16.5 19.79"></polyline>
                        <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
                        <line x1="12" y1="22.08" x2="12" y2="12"></line>
                    </svg>
                </div>
                <h3>AI-Powered Applications</h3>
                <p>Harness the power of artificial intelligence to automate processes, gain insights, and create competitive advantages through machine learning and advanced analytics.</p>
                <ul class="solution-features">
                    <li>Machine Learning Integration</li>
                    <li>Natural Language Processing</li>
                    <li>Predictive Analytics</li>
                    <li>Intelligent Automation</li>
                </ul>
            </div>
            <div class="solution-card">
                <div class="solution-icon">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"></path>
                    </svg>
                </div>
                <h3>Cloud Solutions</h3>
                <p>Modern cloud-native architectures that provide scalability, reliability, and cost-efficiency. From migration to optimization, we deliver comprehensive cloud solutions.</p>
                <ul class="solution-features">
                    <li>Cloud Migration & Modernization</li>
                    <li>Multi-Cloud Architecture</li>
                    <li>DevOps & CI/CD Pipelines</li>
                    <li>Cloud Security & Compliance</li>
                </ul>
            </div>
            <div class="solution-card">
                <div class="solution-icon">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                        <line x1="8" y1="21" x2="16" y2="21"></line>
                        <line x1="12" y1="17" x2="12" y2="21"></line>
                    </svg>
                </div>
                <h3>Enterprise Software</h3>
                <p>Custom-built enterprise applications designed to streamline operations, enhance productivity, and support your unique business processes at scale.</p>
                <ul class="solution-features">
                    <li>Custom Application Development</li>
                    <li>Legacy System Modernization</li>
                    <li>Enterprise Integration</li>
                    <li>Workflow Automation</li>
                </ul>
            </div>
            <div class="solution-card">
                <div class="solution-icon">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M3 3h18v18H3zM21 9H3M21 15H3M12 3v18"></path>
                    </svg>
                </div>
                <h3>Data Analytics</h3>
                <p>Transform raw data into actionable insights with our advanced analytics platforms. Make data-driven decisions with real-time dashboards and predictive models.</p>
                <ul class="solution-features">
                    <li>Business Intelligence Platforms</li>
                    <li>Real-Time Analytics</li>
                    <li>Data Visualization</li>
                    <li>Predictive Modeling</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- Portfolio Preview -->
<section id="portfolio" class="section portfolio">
    <div class="container">
        <div class="section-header centered">
            <span class="section-label">Portfolio</span>
            <h2 class="section-title">Delivering Excellence Across Industries</h2>
            <p class="section-description">Real projects built with real technology -- from AI pipelines and fraud detection to mobile apps and enterprise infrastructure</p>
        </div>
        <div class="portfolio-grid">
            <div class="portfolio-card">
                <div class="portfolio-image">
                    <img src="https://isnbiz-assets-1769962280.s3.us-east-1.amazonaws.com/premium_v3/portfolio/opportunity_bot.webp" alt="AI opportunity research bot dashboard" loading="lazy">
                </div>
                <div class="portfolio-number">01</div>
                <h3>AI Market Intelligence Engine</h3>
                <p>Proprietary AI pipeline that autonomously discovers and scores revenue opportunities across multiple data sources using local LLM inference and RAG-based semantic search — delivering institutional-grade market intelligence at zero marginal cost per query.</p>
                <div class="portfolio-tags">
                    <span class="tag">Python</span>
                    <span class="tag">ChromaDB</span>
                    <span class="tag">Local LLM</span>
                    <span class="tag">RAG</span>
                </div>
            </div>
            <div class="portfolio-card">
                <div class="portfolio-image">
                    <img src="https://isnbiz-assets-1769962280.s3.us-east-1.amazonaws.com/premium_v3/portfolio/infrastructure.webp" alt="TrueNAS infrastructure platform monitoring dashboard" loading="lazy">
                </div>
                <div class="portfolio-number">02</div>
                <h3>Enterprise AI/ML Infrastructure Platform</h3>
                <p>Production-grade on-premise computing platform powering 50+ containerized services across AI inference, multi-database orchestration, and full observability — eliminating six-figure annual cloud dependency while maintaining enterprise SLA standards.</p>
                <div class="portfolio-tags">
                    <span class="tag">Docker</span>
                    <span class="tag">TrueNAS Scale</span>
                    <span class="tag">ZFS</span>
                    <span class="tag">Ollama</span>
                </div>
            </div>
            <div class="portfolio-card">
                <div class="portfolio-image">
                    <img src="https://isnbiz-assets-1769962280.s3.us-east-1.amazonaws.com/premium_v3/portfolio/credit_automation.webp" alt="Enterprise credit report automation interface" loading="lazy">
                </div>
                <div class="portfolio-number">03</div>
                <h3>Automated Compliance & Credit Intelligence</h3>
                <p>Zero-trust credential management system automating multi-bureau credit data aggregation through Playwright browser orchestration and 1Password vault integration — reducing compliance processing time by 95% with auditable, enterprise-grade security.</p>
                <div class="portfolio-tags">
                    <span class="tag">Python</span>
                    <span class="tag">Playwright</span>
                    <span class="tag">1Password CLI</span>
                </div>
            </div>
            <div class="portfolio-card">
                <div class="portfolio-image">
                    <img src="https://isnbiz-assets-1769962280.s3.us-east-1.amazonaws.com/premium_v3/portfolio/rag_bi.webp" alt="BIN intelligence fraud analysis dashboard" loading="lazy">
                </div>
                <div class="portfolio-number">04</div>
                <h3>Payment Fraud Intelligence Platform</h3>
                <p>Real-time BIN enrichment and fraud analytics engine serving the $32B payment fraud prevention market — combining automated feed ingestion, Neutrino API enrichment, and live risk scoring dashboards for e-commerce transaction security.</p>
                <div class="portfolio-tags">
                    <span class="tag">Python</span>
                    <span class="tag">Flask</span>
                    <span class="tag">PostgreSQL</span>
                    <span class="tag">Chart.js</span>
                </div>
            </div>
            <div class="portfolio-card">
                <div class="portfolio-image">
                    <img src="https://isnbiz-assets-1769962280.s3.us-east-1.amazonaws.com/premium_v3/portfolio/androidaps_health.webp" alt="SpiritAtlas Android application screens" loading="lazy">
                </div>
                <div class="portfolio-number">05</div>
                <h3>Privacy-First Consumer Mobile Platform</h3>
                <p>Enterprise-architected Android application showcasing Clean Architecture mastery with encrypted local storage, consent-gated AI routing, and 100+ custom density-optimized assets — demonstrating production mobile engineering at the highest standard.</p>
                <div class="portfolio-tags">
                    <span class="tag">Kotlin</span>
                    <span class="tag">Jetpack Compose</span>
                    <span class="tag">Hilt</span>
                    <span class="tag">Android SDK 34</span>
                </div>
            </div>
            <div class="portfolio-card">
                <div class="portfolio-image">
                    <img src="https://isnbiz-assets-1769962280.s3.us-east-1.amazonaws.com/premium_v3/portfolio/infrastructure.webp" alt="Enterprise AI infrastructure architecture diagram" loading="lazy">
                </div>
                <div class="portfolio-number">06</div>
                <h3>AI Content Production Pipeline</h3>
                <p>End-to-end automated content factory converting raw sources into production-ready video assets using multi-provider AI orchestration (fal.ai, ElevenLabs, Runway) — targeting the $12B creator economy with 10x content velocity at fractional production costs.</p>
                <div class="portfolio-tags">
                    <span class="tag">Node.js</span>
                    <span class="tag">fal.ai</span>
                    <span class="tag">ElevenLabs</span>
                    <span class="tag">AWS S3</span>
                </div>
            </div>
        </div>
        <div class="portfolio-cta">
            <p class="cta-text">Want to see all 9 projects with detailed case studies and results?</p>
            <a href="<?php echo esc_url( home_url( '/portfolio/' ) ); ?>" class="btn btn-outline"><span>View Full Portfolio</span></a>
        </div>
    </div>
</section>

<!-- Investor Section -->
<section id="investors" class="section investors">
    <div class="investors-background"></div>
    <div class="container">
        <div class="section-header centered">
            <span class="section-label investors-label">Investment Opportunity</span>
            <h2 class="section-title">Join Us in Building the Future of Enterprise Software</h2>
            <p class="section-description">We're seeking strategic partners to accelerate growth and expand our market-leading solutions</p>
        </div>
        <div class="investors-grid">
            <div class="investor-card">
                <h3>Market Opportunity</h3>
                <p>The enterprise software market is experiencing unprecedented growth, with AI-powered solutions commanding premium valuations. We're positioned at the intersection of multiple high-growth sectors:</p>
                <ul class="investor-list">
                    <li>AI Infrastructure & Applications</li>
                    <li>Cloud Modernization Services</li>
                    <li>Enterprise Data Analytics</li>
                    <li>Vertical SaaS Solutions</li>
                </ul>
            </div>
            <div class="investor-card">
                <h3>Competitive Advantages</h3>
                <ul class="investor-list">
                    <li><strong>Proven Technology:</strong> 11+ years of successful deployments</li>
                    <li><strong>AI Differentiation:</strong> Deep AI capabilities integrated across platform</li>
                    <li><strong>Client Retention:</strong> 100% retention rate demonstrates product-market fit</li>
                    <li><strong>Scalable Model:</strong> Cloud-native architecture enables rapid scaling</li>
                    <li><strong>Experienced Team:</strong> Proven leadership with domain expertise</li>
                </ul>
            </div>
            <div class="investor-card">
                <h3>Growth Strategy</h3>
                <p>Strategic funding will accelerate our roadmap:</p>
                <ul class="investor-list">
                    <li>Expand sales and marketing team</li>
                    <li>Accelerate product development</li>
                    <li>Scale infrastructure for enterprise clients</li>
                    <li>Enter new vertical markets</li>
                    <li>Strategic partnerships and integrations</li>
                </ul>
            </div>
            <div class="investor-card">
                <h3>Investment Highlights</h3>
                <ul class="investor-list highlight-list">
                    <li>Strong fundamentals with sustainable unit economics</li>
                    <li>Proprietary technology with defensible moats</li>
                    <li>Clear path to profitability</li>
                    <li>Massive addressable market opportunity</li>
                    <li>Strategic positioning in high-priority sectors</li>
                </ul>
            </div>
        </div>
        <div class="investor-cta">
            <div class="investor-cta-content">
                <h3>Ready to Learn More?</h3>
                <p>Access our investor data room to review detailed financials, product roadmap, and market analysis.</p>
                <div class="investor-buttons">
                    <a href="#contact" class="btn btn-primary"><span>Schedule Investor Meeting</span></a>
                    <a href="#contact" class="btn btn-secondary"><span>Request Pitch Deck</span></a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Contact Section -->
<section id="contact" class="section contact">
    <div class="container">
        <div class="section-header centered">
            <span class="section-label">Get in Touch</span>
            <h2 class="section-title">Let's Start a Conversation</h2>
            <p class="section-description">Whether you're interested in our solutions or investment opportunities, we'd love to hear from you</p>
        </div>
        <div class="contact-grid">
            <div class="contact-form-container">
                <form class="contact-form" id="contactForm" method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
                    <input type="hidden" name="action" value="contact_form_submission">
                    <?php wp_nonce_field( 'contact_form_nonce', 'contact_nonce' ); ?>

                    <div class="form-group">
                        <label for="name">Full Name *</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email Address *</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="company">Company</label>
                        <input type="text" id="company" name="company">
                    </div>
                    <div class="form-group">
                        <label for="interest">I'm interested in:</label>
                        <select id="interest" name="interest">
                            <option value="investment">Investment Opportunities</option>
                            <option value="demo">Product Demo</option>
                            <option value="partnership">Partnership Opportunities</option>
                            <option value="services">Software Development Services</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="message">Message *</label>
                        <textarea id="message" name="message" rows="5" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary btn-full">Send Message</button>
                    <p class="form-privacy">We respect your privacy. Your information will be kept confidential.</p>
                </form>
            </div>
            <div class="contact-info">
                <div class="contact-card">
                    <h3>Company Information</h3>
                    <div class="contact-details">
                        <div class="contact-item">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                <circle cx="12" cy="10" r="3"></circle>
                            </svg>
                            <div>
                                <strong>Headquarters</strong>
                                <p>Seattle, Washington</p>
                            </div>
                        </div>
                        <div class="contact-item">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                                <polyline points="22,6 12,13 2,6"></polyline>
                            </svg>
                            <div>
                                <strong>Email</strong>
                                <p><a href="mailto:info@isn.biz">info@isn.biz</a></p>
                            </div>
                        </div>
                        <div class="contact-item">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                            </svg>
                            <div>
                                <strong>Website</strong>
                                <p><a href="<?php echo esc_url( home_url( '/' ) ); ?>">isn.biz</a></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="contact-card">
                    <h3>For Investors</h3>
                    <p>Qualified investors can request access to our secure data room for detailed financial information, product roadmap, and due diligence materials.</p>
                    <a href="#contact" class="btn btn-outline btn-small">Request Data Room Access</a>
                </div>
                <div class="contact-card">
                    <h3>Response Time</h3>
                    <p>We typically respond to all inquiries within 24 business hours. For urgent matters, please indicate in your message.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
