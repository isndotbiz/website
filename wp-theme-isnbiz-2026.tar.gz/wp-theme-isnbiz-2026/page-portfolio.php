<?php
/*
Template Name: Portfolio
Description: Portfolio page template with 9 production-grade AI and enterprise systems
*/

get_header();
?>

<!-- WCAG FIX: Skip navigation link for keyboard users -->
    <a href="#opportunity-bot" class="skip-link">Skip to main content</a>

    <!-- Navigation -->
    

    <!-- Hero Section -->
    <section class="hero portfolio-hero">
        <div class="hero-background"></div>
        <div class="container hero-container">
            <div class="hero-content">
                <h1 class="hero-title">Proven Engineering, Enterprise-Scale Execution</h1>
                <p class="hero-subtitle">Each project represents production-ready IP — architected for scalability, security, and measurable enterprise value</p>
                <div class="portfolio-hero-stats">
                    <div class="stat">
                        <div class="stat-number">9</div>
                        <div class="stat-label">Production Systems</div>
                    </div>
                    <div class="stat">
                        <div class="stat-number">50+</div>
                        <div class="stat-label">Containers Deployed</div>
                    </div>
                    <div class="stat">
                        <div class="stat-number">10x</div>
                        <div class="stat-label">Efficiency Gains</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Project 1: Opportunity Research Bot -->
    <section id="opportunity-bot" class="section project-detail">
        <div class="container">
            <div class="project-content">
                <div class="project-header">
                    <span class="project-number">01</span>
                    <div class="project-tags">
                        <span class="tag">AI/ML</span>
                        <span class="tag">RAG System</span>
                        <span class="tag">Automation</span>
                        <span class="tag">Python</span>
                    </div>
                </div>
                <h2 class="project-title">AI Market Intelligence Engine</h2>
                <p class="project-subtitle">Autonomous opportunity discovery platform with proprietary scoring and financial-profile matching across the $14B market intelligence sector</p>

                <div class="project-grid">
                    <div class="project-description">
                        <h3>The Challenge</h3>
                        <p>Enterprise market intelligence platforms cost $50K-$500K annually and still require significant human analysis. Most solutions lack financial profiling integration, creating a gap between opportunity identification and capital deployment readiness.</p>

                        <h3>Our Solution</h3>
                        <p>Engineered a proprietary AI pipeline combining multi-source data acquisition (Reddit, Indie Hackers, Google), local LLM analysis via Qwen 30B, and ChromaDB vector search with FICO credit profile matching — delivering institutionally-relevant opportunity scoring at zero marginal inference cost.</p>

                        <h3>The Result</h3>
                        <p>A fully autonomous, 24/7 intelligence engine that replaces six-figure market research subscriptions with on-premise AI inference, providing unlimited queries with complete data sovereignty and zero vendor dependency.</p>
                    </div>

                    <div class="project-metrics">
                        <div class="project-media">
                            <img src="https://isnbiz-assets-1769962280.s3.us-east-1.amazonaws.com/premium_v3/portfolio/opportunity_bot.webp" alt="Opportunity Research Bot dashboard" loading="lazy">
                        </div>
                        <div class="metric-card">
                            <h3>Technology Stack</h3>
                            <div class="tech-stack">
                                <span class="tech-badge">Python</span>
                                <span class="tech-badge">PRAW</span>
                                <span class="tech-badge">ChromaDB</span>
                                <span class="tech-badge">Qwen LLM</span>
                                <span class="tech-badge">RAG Pipeline</span>
                                <span class="tech-badge">llama.cpp</span>
                            </div>
                        </div>

                        <div class="metric-card">
                            <h3>Measurable Results</h3>
                            <div class="metrics-grid">
                                <div class="metric">
                                    <div class="metric-value">95%</div>
                                    <div class="metric-label">Reduction in Analysis Cycle Time</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">24/7</div>
                                    <div class="metric-label">Autonomous Market Coverage</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">3+</div>
                                    <div class="metric-label">Integrated Data Channels</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">$0</div>
                                    <div class="metric-label">Marginal Cost Per Query</div>
                                </div>
                            </div>
                        </div>

                        <div class="metric-card">
                            <h3>Business Impact</h3>
                            <ul class="impact-list">
                                <li>Replaces $50K-$500K annual market intelligence subscriptions</li>
                                <li>Financial-profile matching enables capital-ready opportunity scoring</li>
                                <li>Complete data sovereignty — zero third-party data exposure</li>
                                <li>Scalable to unlimited concurrent analysis streams</li>
                            </ul>
                        </div>

                        <div class="metric-card highlight-card">
                            <h3>Innovation Highlight</h3>
                            <p><strong>First platform to integrate credit profile analysis with AI-driven opportunity discovery</strong> — matching institutional investment criteria to real-time market signals.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Project 2: TrueNAS Infrastructure Platform -->
    <section id="truenas-infrastructure" class="section project-detail alt-bg">
        <div class="container">
            <div class="project-content">
                <div class="project-header">
                    <span class="project-number">02</span>
                    <div class="project-tags">
                        <span class="tag">Infrastructure</span>
                        <span class="tag">DevOps</span>
                        <span class="tag">AI Platform</span>
                        <span class="tag">Self-Hosted</span>
                    </div>
                </div>
                <h2 class="project-title">Enterprise AI/ML Infrastructure Platform</h2>
                <p class="project-subtitle">Production-grade on-premise computing platform eliminating cloud dependency with 50+ containerized services and enterprise observability</p>

                <div class="project-grid">
                    <div class="project-description">
                        <h3>The Challenge</h3>
                        <p>Enterprise AI workloads on AWS/Azure/GCP generate $100K-$1M+ in annual compute costs with vendor lock-in, data sovereignty risks, and unpredictable scaling bills. Organizations need full infrastructure control without sacrificing enterprise-grade reliability.</p>

                        <h3>Our Solution</h3>
                        <p>Architected a production on-premise platform on TrueNAS Scale deploying 50+ Docker containers across AI inference (Ollama, llama.cpp), multi-database orchestration (Neo4j, Redis, PostgreSQL, ClickHouse), full Prometheus/Grafana observability, and Traefik reverse proxy routing — all secured through 1Password-based secret injection.</p>

                        <h3>The Result</h3>
                        <p>A self-hosted enterprise platform with 247GB RAM capacity, ZFS-backed storage redundancy, and 99.9% uptime — delivering cloud-equivalent AI/ML capabilities while eliminating six-figure annual cloud expenditure and maintaining complete data sovereignty.</p>
                    </div>

                    <div class="project-metrics">
                        <div class="project-media">
                            <img src="https://isnbiz-assets-1769962280.s3.us-east-1.amazonaws.com/premium_v3/portfolio/infrastructure.webp" alt="TrueNAS Infrastructure Platform monitoring dashboard" loading="lazy">
                        </div>
                        <div class="metric-card">
                            <h3>Technology Stack</h3>
                            <div class="tech-stack">
                                <span class="tech-badge">Docker</span>
                                <span class="tech-badge">TrueNAS Scale</span>
                                <span class="tech-badge">ZFS</span>
                                <span class="tech-badge">Ollama</span>
                                <span class="tech-badge">Neo4j</span>
                                <span class="tech-badge">Redis</span>
                                <span class="tech-badge">PostgreSQL</span>
                                <span class="tech-badge">ClickHouse</span>
                                <span class="tech-badge">Traefik</span>
                                <span class="tech-badge">Prometheus</span>
                                <span class="tech-badge">Grafana</span>
                            </div>
                        </div>

                        <div class="metric-card">
                            <h3>Infrastructure Scale</h3>
                            <div class="metrics-grid">
                                <div class="metric">
                                    <div class="metric-value">50+</div>
                                    <div class="metric-label">Production Containers Deployed</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">247 GB</div>
                                    <div class="metric-label">RAM Capacity (Enterprise-Scale)</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">99.9%</div>
                                    <div class="metric-label">Platform Availability Target</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">6+</div>
                                    <div class="metric-label">Integrated Database Engines</div>
                                </div>
                            </div>
                        </div>

                        <div class="metric-card">
                            <h3>Business Impact</h3>
                            <ul class="impact-list">
                                <li>Eliminates $100K-$1M+ annual cloud computing dependency</li>
                                <li>Complete data sovereignty for regulated industries and sensitive IP</li>
                                <li>Multi-database architecture supports any enterprise workload pattern</li>
                                <li>ZFS replication provides enterprise-grade disaster recovery</li>
                            </ul>
                        </div>

                        <div class="metric-card highlight-card">
                            <h3>Innovation Highlight</h3>
                            <p><strong>Integrated AI Router providing OpenAI-compatible API endpoints across local and external models</strong> — enabling seamless model migration and vendor-agnostic AI deployment.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Project 3: Enterprise Credit Report Automation -->
    <section id="credit-automation" class="section project-detail">
        <div class="container">
            <div class="project-content">
                <div class="project-header">
                    <span class="project-number">03</span>
                    <div class="project-tags">
                        <span class="tag">Automation</span>
                        <span class="tag">Security</span>
                        <span class="tag">Browser Automation</span>
                        <span class="tag">Python</span>
                    </div>
                </div>
                <h2 class="project-title">Automated Compliance & Credit Intelligence</h2>
                <p class="project-subtitle">Zero-trust automated credit data aggregation with enterprise-grade credential management</p>

                <div class="project-grid">
                    <div class="project-description">
                        <h3>The Challenge</h3>
                        <p>Manual multi-bureau credit monitoring consumes significant operational hours and introduces human error into compliance-critical data workflows. Credential management across multiple financial platforms creates security vulnerabilities.</p>

                        <h3>Our Solution</h3>
                        <p>Built a zero-trust automation system using Playwright browser orchestration and 1Password CLI vault integration to aggregate credit data from Equifax Business, Nav, and myFICO — with fully auditable credential injection and zero hardcoded secrets.</p>

                        <h3>The Result</h3>
                        <p>Eliminated 95% of manual compliance processing time while establishing enterprise-grade security posture — fully auditable, zero-trust architecture suitable for regulated financial environments.</p>
                    </div>

                    <div class="project-metrics">
                        <div class="project-media">
                            <img src="https://isnbiz-assets-1769962280.s3.us-east-1.amazonaws.com/premium_v3/portfolio/credit_automation.webp" alt="Credit report automation system interface" loading="lazy">
                        </div>
                        <div class="metric-card">
                            <h3>Technology Stack</h3>
                            <div class="tech-stack">
                                <span class="tech-badge">Python</span>
                                <span class="tech-badge">Playwright</span>
                                <span class="tech-badge">1Password CLI</span>
                                <span class="tech-badge">JSON</span>
                                <span class="tech-badge">Bash</span>
                            </div>
                        </div>

                        <div class="metric-card">
                            <h3>Measurable Results</h3>
                            <div class="metrics-grid">
                                <div class="metric">
                                    <div class="metric-value">95%</div>
                                    <div class="metric-label">Compliance Processing Time Reduction</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">3</div>
                                    <div class="metric-label">Bureau Sources Automated</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">0</div>
                                    <div class="metric-label">Hardcoded Credentials</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">100%</div>
                                    <div class="metric-label">Audit Trail Coverage</div>
                                </div>
                            </div>
                        </div>

                        <div class="metric-card">
                            <h3>Business Impact</h3>
                            <ul class="impact-list">
                                <li>Eliminates six-figure operational overhead in compliance workflows</li>
                                <li>Zero-trust credential architecture meets SOC 2 and financial regulatory standards</li>
                                <li>Structured output feeds directly into downstream intelligence systems</li>
                                <li>Scalable to any number of financial data sources and bureau integrations</li>
                            </ul>
                        </div>

                        <div class="metric-card highlight-card">
                            <h3>Innovation Highlight</h3>
                            <p><strong>Zero-trust credential orchestration for financial data aggregation</strong> — achieving 100% audit trail coverage with zero hardcoded secrets, setting the standard for compliant automation in regulated industries.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Project 4: BIN Intelligence System -->
    <section id="bin-intelligence" class="section project-detail alt-bg">
        <div class="container">
            <div class="project-content">
                <div class="project-header">
                    <span class="project-number">04</span>
                    <div class="project-tags">
                        <span class="tag">Fraud Detection</span>
                        <span class="tag">Analytics</span>
                        <span class="tag">Flask</span>
                        <span class="tag">Python</span>
                    </div>
                </div>
                <h2 class="project-title">Payment Fraud Intelligence Platform</h2>
                <p class="project-subtitle">Real-time BIN enrichment and fraud analytics engine targeting the $32B payment security market</p>

                <div class="project-grid">
                    <div class="project-description">
                        <h3>The Challenge</h3>
                        <p>Card-not-present fraud costs the global e-commerce industry $32B+ annually. Fraud teams lack real-time BIN intelligence and automated feed analysis, creating detection gaps that result in significant revenue loss.</p>

                        <h3>Our Solution</h3>
                        <p>Developed a comprehensive BIN intelligence platform combining automated fraud feed scraping, Neutrino API enrichment, classification engine, and real-time analytics dashboard with REST API — providing institutional-grade payment risk intelligence.</p>

                        <h3>The Result</h3>
                        <p>A production-ready fraud intelligence platform positioning ISN.BIZ in the $32B payment fraud prevention market with proprietary data enrichment, live risk scoring, and API-first architecture ready for SaaS distribution.</p>
                    </div>

                    <div class="project-metrics">
                        <div class="project-media">
                            <img src="https://isnbiz-assets-1769962280.s3.us-east-1.amazonaws.com/premium_v3/portfolio/rag_bi.webp" alt="BIN Intelligence fraud analytics dashboard" loading="lazy">
                        </div>
                        <div class="metric-card">
                            <h3>Technology Stack</h3>
                            <div class="tech-stack">
                                <span class="tech-badge">Python</span>
                                <span class="tech-badge">Flask</span>
                                <span class="tech-badge">PostgreSQL</span>
                                <span class="tech-badge">Neutrino API</span>
                                <span class="tech-badge">Chart.js</span>
                                <span class="tech-badge">HTML/CSS</span>
                            </div>
                        </div>

                        <div class="metric-card">
                            <h3>System Capabilities</h3>
                            <div class="metrics-grid">
                                <div class="metric">
                                    <div class="metric-value">Real-Time</div>
                                    <div class="metric-label">BIN Enrichment Speed</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">$32B+</div>
                                    <div class="metric-label">Addressable Market (Payment Fraud)</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">REST API</div>
                                    <div class="metric-label">Enterprise Integration Ready</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">Dashboard</div>
                                    <div class="metric-label">Live Risk Scoring</div>
                                </div>
                            </div>
                        </div>

                        <div class="metric-card">
                            <h3>Business Impact</h3>
                            <ul class="impact-list">
                                <li>Positions ISN.BIZ in the $32B+ global payment fraud prevention market</li>
                                <li>API-first architecture enables white-label SaaS distribution</li>
                                <li>Proprietary enrichment pipeline creates defensible competitive moat</li>
                                <li>Real-time scoring reduces chargeback exposure across merchant portfolios</li>
                            </ul>
                        </div>

                        <div class="metric-card highlight-card">
                            <h3>Innovation Highlight</h3>
                            <p><strong>Integrated fraud feed scraping with real-time BIN enrichment and live risk scoring</strong> — delivering institutional-grade payment intelligence through a self-hosted, API-driven platform ready for enterprise deployment.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Project 5: SpiritAtlas -->
    <section id="spiritatlas" class="section project-detail">
        <div class="container">
            <div class="project-content">
                <div class="project-header">
                    <span class="project-number">05</span>
                    <div class="project-tags">
                        <span class="tag">Android</span>
                        <span class="tag">Kotlin</span>
                        <span class="tag">Privacy-First</span>
                        <span class="tag">AI Integration</span>
                    </div>
                </div>
                <h2 class="project-title">Privacy-First Consumer Mobile Platform</h2>
                <p class="project-subtitle">Enterprise-architected Android application demonstrating production mobile engineering excellence</p>

                <div class="project-grid">
                    <div class="project-description">
                        <h3>The Challenge</h3>
                        <p>Consumer mobile applications in the wellness and personalization space face growing regulatory pressure around data privacy, with GDPR/CCPA compliance requiring architecturally sound privacy-by-design approaches.</p>

                        <h3>Our Solution</h3>
                        <p>Architected a multi-module Android application using Clean Architecture (app, feature, domain, data, core), Jetpack Compose Material 3 UI, Hilt dependency injection, consent-gated AI routing, and EncryptedSharedPreferences — delivering privacy-first design at architectural scale.</p>

                        <h3>The Result</h3>
                        <p>A production-grade mobile application demonstrating ISN.BIZ's capacity for regulated consumer software engineering — with 100+ custom visual assets, dedicated calculation test suites, and security documentation meeting enterprise compliance standards.</p>
                    </div>

                    <div class="project-metrics">
                        <div class="project-media">
                            <img src="https://isnbiz-assets-1769962280.s3.us-east-1.amazonaws.com/premium_v3/portfolio/androidaps_health.webp" alt="SpiritAtlas Android app screens" loading="lazy">
                        </div>
                        <div class="metric-card">
                            <h3>Technology Stack</h3>
                            <div class="tech-stack">
                                <span class="tech-badge">Kotlin</span>
                                <span class="tech-badge">Jetpack Compose</span>
                                <span class="tech-badge">Hilt</span>
                                <span class="tech-badge">Android SDK 34</span>
                                <span class="tech-badge">SSL Pinning</span>
                                <span class="tech-badge">Encrypted Storage</span>
                            </div>
                        </div>

                        <div class="metric-card">
                            <h3>App Architecture</h3>
                            <div class="metrics-grid">
                                <div class="metric">
                                    <div class="metric-value">119</div>
                                    <div class="metric-label">Custom Density-Optimized Assets</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">5</div>
                                    <div class="metric-label">Independent Feature Modules</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">SDK 34</div>
                                    <div class="metric-label">Latest Android Platform</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">100%</div>
                                    <div class="metric-label">Privacy-by-Design Compliance</div>
                                </div>
                            </div>
                        </div>

                        <div class="metric-card">
                            <h3>Business Impact</h3>
                            <ul class="impact-list">
                                <li>Demonstrates enterprise-grade mobile engineering for regulated markets</li>
                                <li>Clean Architecture enables rapid scaling and team onboarding</li>
                                <li>GDPR/CCPA-ready privacy architecture reduces regulatory risk</li>
                                <li>Consent-gated AI routing establishes responsible AI deployment patterns</li>
                            </ul>
                        </div>

                        <div class="metric-card highlight-card">
                            <h3>Innovation Highlight</h3>
                            <p><strong>Privacy-by-design architecture with consent-gated AI routing</strong> — proving that consumer mobile platforms can deliver personalized AI experiences while maintaining full regulatory compliance and zero unauthorized data exposure.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Project 6: VideoGen YouTube Pipeline -->
    <section id="videogen" class="section project-detail alt-bg">
        <div class="container">
            <div class="project-content">
                <div class="project-header">
                    <span class="project-number">06</span>
                    <div class="project-tags">
                        <span class="tag">Content Automation</span>
                        <span class="tag">Node.js</span>
                        <span class="tag">AI Pipeline</span>
                        <span class="tag">Video</span>
                    </div>
                </div>
                <h2 class="project-title">AI Content Production Pipeline</h2>
                <p class="project-subtitle">End-to-end automated video production targeting the $12B creator economy</p>

                <div class="project-grid">
                    <div class="project-description">
                        <h3>The Challenge</h3>
                        <p>Professional video content production costs $5K-$50K per asset and requires weeks of turnaround. The $12B creator economy demands scalable content velocity that traditional production workflows cannot deliver.</p>

                        <h3>Our Solution</h3>
                        <p>Engineered an end-to-end pipeline automating the full content lifecycle: article scraping, script generation, storyboard creation, AI narration (ElevenLabs), image/animation generation (fal.ai, Runway), video assembly, and YouTube upload with SEO metadata.</p>

                        <h3>The Result</h3>
                        <p>A content production factory delivering 10x throughput at a fraction of traditional costs — positioning ISN.BIZ to capture value in the rapidly growing automated content creation market.</p>
                    </div>

                    <div class="project-metrics">
                        <div class="project-media">
                            <img src="https://isnbiz-assets-1769962280.s3.us-east-1.amazonaws.com/premium_v3/services/ai_research.webp" alt="VideoGen YouTube Pipeline workflow" loading="lazy">
                        </div>
                        <div class="metric-card">
                            <h3>Technology Stack</h3>
                            <div class="tech-stack">
                                <span class="tech-badge">Node.js</span>
                                <span class="tech-badge">fal.ai</span>
                                <span class="tech-badge">ElevenLabs</span>
                                <span class="tech-badge">Descript</span>
                                <span class="tech-badge">AWS S3</span>
                                <span class="tech-badge">YouTube API</span>
                            </div>
                        </div>

                        <div class="metric-card">
                            <h3>Pipeline Stages</h3>
                            <div class="metrics-grid">
                                <div class="metric">
                                    <div class="metric-value">10x</div>
                                    <div class="metric-label">Content Velocity Multiplier</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">$12B</div>
                                    <div class="metric-label">Addressable Creator Economy</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">E2E</div>
                                    <div class="metric-label">Fully Automated Pipeline</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">Multi</div>
                                    <div class="metric-label">AI Provider Orchestration</div>
                                </div>
                            </div>
                        </div>

                        <div class="metric-card">
                            <h3>Business Impact</h3>
                            <ul class="impact-list">
                                <li>Eliminates $5K-$50K per-asset production costs at enterprise scale</li>
                                <li>10x content velocity positions for creator economy market capture</li>
                                <li>Multi-provider AI orchestration creates resilient, vendor-agnostic pipeline</li>
                                <li>S3-backed media architecture scales to unlimited content libraries</li>
                            </ul>
                        </div>

                        <div class="metric-card highlight-card">
                            <h3>Innovation Highlight</h3>
                            <p><strong>Full-lifecycle AI content orchestration</strong> — seamlessly integrating text generation, voice synthesis, image creation, video assembly, and platform distribution into a single autonomous pipeline targeting the $12B creator economy.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Project 7: HROC Non-Profit Website -->
    <section id="hroc-website" class="section project-detail">
        <div class="container">
            <div class="project-content">
                <div class="project-header">
                    <span class="project-number">07</span>
                    <div class="project-tags">
                        <span class="tag">Generative AI</span>
                        <span class="tag">Image Pipeline</span>
                        <span class="tag">Python</span>
                        <span class="tag">GPU Compute</span>
                    </div>
                </div>
                <h2 class="project-title">Generative AI Production Pipeline</h2>
                <p class="project-subtitle">Scalable API-driven image generation infrastructure with LoRA management and batch orchestration</p>

                <div class="project-grid">
                    <div class="project-description">
                        <h3>The Challenge</h3>
                        <p>Generative AI image production at scale requires programmatic pipeline control beyond manual GUI operation. Enterprise creative teams and content production houses need repeatable, API-driven workflows with consistent brand quality across thousands of asset generations.</p>

                        <h3>Our Solution</h3>
                        <p>Built a complete automation suite for ComfyUI integrating Flux model workflows, API-driven prompt queueing, LoRA model management, and config-driven batch generation — transforming manual image creation into programmable, production-scale generative AI output with brand consistency guarantees.</p>

                        <h3>The Result</h3>
                        <p>An enterprise-ready generative AI pipeline converting manual creative workflows into programmable, scalable content production systems — ready for white-label deployment to marketing agencies, content studios, and internal enterprise creative operations.</p>
                    </div>

                    <div class="project-metrics">
                        <div class="project-media">
                            <img src="https://isnbiz-assets-1769962280.s3.us-east-1.amazonaws.com/premium_v3/portfolio/comfyui_wan.webp" alt="ComfyUI Flux automation pipeline" loading="lazy">
                        </div>
                        <div class="metric-card">
                            <h3>Technology Stack</h3>
                            <div class="tech-stack">
                                <span class="tech-badge">Python 3.10+</span>
                                <span class="tech-badge">ComfyUI API</span>
                                <span class="tech-badge">Flux Models</span>
                                <span class="tech-badge">LoRA</span>
                                <span class="tech-badge">GPU Compute</span>
                                <span class="tech-badge">YAML Config</span>
                                <span class="tech-badge">fal.ai</span>
                                <span class="tech-badge">Replicate</span>
                            </div>
                        </div>

                        <div class="metric-card">
                            <h3>System Capabilities</h3>
                            <div class="metrics-grid">
                                <div class="metric">
                                    <div class="metric-value">API-First</div>
                                    <div class="metric-label">Programmatic Workflow Control</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">1000s</div>
                                    <div class="metric-label">Concurrent Batch Generations</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">LoRA</div>
                                    <div class="metric-label">Brand-Consistent Fine-Tuning</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">YAML</div>
                                    <div class="metric-label">Repeatable Config Management</div>
                                </div>
                            </div>
                        </div>

                        <div class="metric-card">
                            <h3>Business Impact</h3>
                            <ul class="impact-list">
                                <li>Converts manual creative workflows into programmable production systems at enterprise scale</li>
                                <li>White-label ready for SaaS deployment to marketing agencies and content studios</li>
                                <li>LoRA fine-tuning ensures brand-consistent output across unlimited asset generations</li>
                                <li>Multi-provider integration (fal.ai, Replicate) creates vendor-agnostic resilience</li>
                            </ul>
                        </div>

                        <div class="metric-card highlight-card">
                            <h3>Innovation Highlight</h3>
                            <p><strong>API-driven generative AI orchestration with LoRA model management</strong> — transforming ComfyUI from an interactive tool into a production-grade, programmable content generation platform ready for white-label SaaS distribution to enterprise creative teams.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Project 8: ComfyUI Flux WAN Automation -->
    <section id="comfyui-automation" class="section project-detail alt-bg">
        <div class="container">
            <div class="project-content">
                <div class="project-header">
                    <span class="project-number">08</span>
                    <div class="project-tags">
                        <span class="tag">Data Processing</span>
                        <span class="tag">Validation</span>
                        <span class="tag">Python</span>
                        <span class="tag">Enterprise</span>
                    </div>
                </div>
                <h2 class="project-title">Enterprise GEDCOM Processing Engine</h2>
                <p class="project-subtitle">Professional-grade genealogical data normalization with zero-data-loss guarantees and relationship-preserving integrity</p>

                <div class="project-grid">
                    <div class="project-description">
                        <h3>The Challenge</h3>
                        <p>Legacy genealogical datasets contain thousands of format inconsistencies that require expensive manual cleanup and risk data integrity loss. Enterprise genealogy platforms and archival institutions need automated processing that maintains relationship fidelity while standardizing inconsistent date formats, name conventions, and place references.</p>

                        <h3>Our Solution</h3>
                        <p>Developed a production-grade CLI (gedfix) implementing rule-based normalization for dates, names, and places with GEDCOM 5.5.1 compliance, relationship-preserving deduplication logic, automated integrity verification with full backup/rollback capability, and comprehensive audit trails meeting archival standards.</p>

                        <h3>The Result</h3>
                        <p>Processed 2,272 data issues with 100% integrity preservation and zero data loss — demonstrating ISN.BIZ's capability to build auditable, enterprise-grade data processing systems applicable across regulated industries from genealogy platforms to healthcare record normalization.</p>
                    </div>

                    <div class="project-metrics">
                        <div class="project-media">
                            <img src="https://isnbiz-assets-1769962280.s3.us-east-1.amazonaws.com/premium_v3/portfolio/gedcom_processing.webp" alt="GEDCOM processing engine results" loading="lazy">
                        </div>
                        <div class="metric-card">
                            <h3>Technology Stack</h3>
                            <div class="tech-stack">
                                <span class="tech-badge">Python 3.11</span>
                                <span class="tech-badge">ged4py</span>
                                <span class="tech-badge">Click CLI</span>
                                <span class="tech-badge">rapidfuzz</span>
                                <span class="tech-badge">Rule Engine</span>
                                <span class="tech-badge">Data Validation</span>
                                <span class="tech-badge">Audit Logging</span>
                                <span class="tech-badge">Backup/Rollback</span>
                            </div>
                        </div>

                        <div class="metric-card">
                            <h3>Proven Results</h3>
                            <div class="metrics-grid">
                                <div class="metric">
                                    <div class="metric-value">2,272</div>
                                    <div class="metric-label">Data Issues Resolved with AutoFix</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">100%</div>
                                    <div class="metric-label">Data Integrity Preservation</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">584</div>
                                    <div class="metric-label">Media Assets Reattached</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">Zero</div>
                                    <div class="metric-label">Data Loss Incidents</div>
                                </div>
                            </div>
                        </div>

                        <div class="metric-card">
                            <h3>Business Impact</h3>
                            <ul class="impact-list">
                                <li>Demonstrates enterprise-grade data processing capabilities for regulated archival and healthcare sectors</li>
                                <li>Zero-data-loss architecture with audit trails meets GEDCOM, SOX, and HIPAA compliance requirements</li>
                                <li>Full backup/rollback capability ensures safe processing of irreplaceable genealogical records</li>
                                <li>Rule-engine architecture scales to any structured data normalization domain across industries</li>
                            </ul>
                        </div>

                        <div class="metric-card highlight-card">
                            <h3>Innovation Highlight</h3>
                            <p><strong>Relationship-preserving deduplication with zero-data-loss guarantees</strong> — solving the universal enterprise challenge of legacy data normalization with auditable, production-grade processing applicable from genealogy platforms to healthcare records to financial data archival.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Project 9: LLM Optimization Framework -->
    <section id="llm-optimization" class="section project-detail">
        <div class="container">
            <div class="project-content">
                <div class="project-header">
                    <span class="project-number">09</span>
                    <div class="project-tags">
                        <span class="tag">LLM Research</span>
                        <span class="tag">Python</span>
                        <span class="tag">Visualization</span>
                        <span class="tag">Flask</span>
                    </div>
                </div>
                <h2 class="project-title">AI Safety & Evaluation Framework</h2>
                <p class="project-subtitle">Structured LLM evaluation and behavior analysis platform for enterprise AI governance</p>

                <div class="project-grid">
                    <div class="project-description">
                        <h3>The Challenge</h3>
                        <p>Enterprise LLM deployment requires structured evaluation, safety testing, and measurable governance metrics. Without systematic assessment, organizations face regulatory and reputational risk from uncontrolled AI behavior.</p>

                        <h3>Our Solution</h3>
                        <p>Created a comprehensive framework combining evaluation dashboards, technique taxonomy libraries, OPML exports, and interactive visualization tools — providing decision-makers with evidence-based AI governance intelligence.</p>

                        <h3>The Result</h3>
                        <p>A structured AI governance toolkit positioning ISN.BIZ at the intersection of AI safety and enterprise compliance — addressing the rapidly growing demand for AI governance solutions as regulations like the EU AI Act take effect.</p>
                    </div>

                    <div class="project-metrics">
                        <div class="project-media">
                            <img src="https://isnbiz-assets-1769962280.s3.us-east-1.amazonaws.com/premium_v3/services/rag_and_search.webp" alt="LLM Optimization Framework dashboard" loading="lazy">
                        </div>
                        <div class="metric-card">
                            <h3>Technology Stack</h3>
                            <div class="tech-stack">
                                <span class="tech-badge">Python</span>
                                <span class="tech-badge">Flask</span>
                                <span class="tech-badge">SQLite</span>
                                <span class="tech-badge">Mindmap Viz</span>
                                <span class="tech-badge">REST API</span>
                                <span class="tech-badge">HTML/JS</span>
                            </div>
                        </div>

                        <div class="metric-card">
                            <h3>Framework Capabilities</h3>
                            <div class="metrics-grid">
                                <div class="metric">
                                    <div class="metric-value">Dashboard</div>
                                    <div class="metric-label">Real-Time Evaluation Analytics</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">Taxonomy</div>
                                    <div class="metric-label">Structured Technique Library</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">OPML</div>
                                    <div class="metric-label">Exportable Knowledge Graphs</div>
                                </div>
                                <div class="metric">
                                    <div class="metric-value">Compliance</div>
                                    <div class="metric-label">Regulatory-Ready Reporting</div>
                                </div>
                            </div>
                        </div>

                        <div class="metric-card">
                            <h3>Business Impact</h3>
                            <ul class="impact-list">
                                <li>Positions ISN.BIZ in the rapidly expanding AI governance and compliance market</li>
                                <li>Evidence-based evaluation enables enterprise-grade AI deployment decisions</li>
                                <li>Exportable knowledge graphs support cross-organizational AI governance</li>
                                <li>Regulatory-ready reporting addresses EU AI Act and emerging compliance frameworks</li>
                            </ul>
                        </div>

                        <div class="metric-card highlight-card">
                            <h3>Innovation Highlight</h3>
                            <p><strong>Structured AI governance with exportable evaluation intelligence</strong> — combining real-time behavior analysis, technique taxonomy, and compliance-ready reporting into an enterprise platform addressing the critical gap in AI safety tooling.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Technology Expertise Section -->
    <section id="technology-stack" class="section tech-expertise">
        <div class="container">
            <div class="section-header centered">
                <span class="section-label">Technology Expertise</span>
                <h2 class="section-title">Enterprise-Grade Technical Capabilities</h2>
                <p class="section-description">Production-proven expertise across AI/ML, infrastructure, security, and full-stack engineering</p>
            </div>

            <div class="tech-expertise-grid">
                <div class="tech-category">
                    <h3>AI & Machine Learning</h3>
                    <div class="tech-list">
                        <span>Qwen 30B LLM</span>
                        <span>llama.cpp</span>
                        <span>Ollama</span>
                        <span>Flux Models</span>
                        <span>ComfyUI API</span>
                        <span>LoRA Fine-Tuning</span>
                        <span>ChromaDB</span>
                        <span>RAG Pipelines</span>
                        <span>ElevenLabs</span>
                        <span>fal.ai</span>
                        <span>AI Governance</span>
                    </div>
                </div>

                <div class="tech-category">
                    <h3>Programming & Frameworks</h3>
                    <div class="tech-list">
                        <span>Python</span>
                        <span>Kotlin</span>
                        <span>Node.js</span>
                        <span>JavaScript</span>
                        <span>Bash/Shell</span>
                        <span>HTML5/CSS3</span>
                        <span>SQL</span>
                        <span>Flask</span>
                        <span>Clean Architecture</span>
                    </div>
                </div>

                <div class="tech-category">
                    <h3>Infrastructure & DevOps</h3>
                    <div class="tech-list">
                        <span>Docker (50+ Containers)</span>
                        <span>TrueNAS Scale</span>
                        <span>ZFS Replication</span>
                        <span>Traefik Proxy</span>
                        <span>Prometheus</span>
                        <span>Grafana</span>
                        <span>AWS S3</span>
                        <span>Git/GitHub</span>
                        <span>Linux Administration</span>
                        <span>GPU Compute (RTX 3090/4060Ti)</span>
                    </div>
                </div>

                <div class="tech-category">
                    <h3>Security & Automation</h3>
                    <div class="tech-list">
                        <span>1Password CLI (Zero-Trust)</span>
                        <span>Playwright</span>
                        <span>SSL Pinning</span>
                        <span>EncryptedSharedPreferences</span>
                        <span>PRAW (Reddit API)</span>
                        <span>YouTube API</span>
                        <span>Neutrino API</span>
                        <span>Audit Trail Systems</span>
                        <span>REST APIs</span>
                    </div>
                </div>

                <div class="tech-category">
                    <h3>Databases & Data Processing</h3>
                    <div class="tech-list">
                        <span>PostgreSQL</span>
                        <span>Neo4j (Graph)</span>
                        <span>Redis Stack</span>
                        <span>ClickHouse (Analytics)</span>
                        <span>ChromaDB (Vectors)</span>
                        <span>SQLite</span>
                        <span>Data Normalization Engines</span>
                        <span>Rule-Based Validation</span>
                    </div>
                </div>

                <div class="tech-category">
                    <h3>Mobile & Application Layer</h3>
                    <div class="tech-list">
                        <span>Android SDK 34</span>
                        <span>Jetpack Compose (Material 3)</span>
                        <span>Hilt Dependency Injection</span>
                        <span>Chart.js Analytics</span>
                        <span>WebSocket Integration</span>
                        <span>OPML/Knowledge Graphs</span>
                        <span>Mindmap Visualization</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Project Methodology -->
    <section id="methodology" class="section methodology">
        <div class="container">
            <div class="section-header centered">
                <span class="section-label">Engineering Methodology</span>
                <h2 class="section-title">Enterprise-Grade Development Process</h2>
            </div>

            <div class="methodology-grid">
                <div class="methodology-step">
                    <div class="step-number">1</div>
                    <h3>Market & Technical Discovery</h3>
                    <p>Rigorous analysis of TAM, competitive landscape, and technical feasibility. Every system is designed with market positioning and scalability economics from inception.</p>
                </div>

                <div class="methodology-step">
                    <div class="step-number">2</div>
                    <h3>Scalable Architecture Design</h3>
                    <p>Zero-trust security posture, multi-database orchestration, and vendor-agnostic infrastructure. Architected for enterprise compliance and horizontal scalability.</p>
                </div>

                <div class="methodology-step">
                    <div class="step-number">3</div>
                    <h3>Production-First Development</h3>
                    <p>Every component built to production standards with comprehensive audit trails, automated testing, and deployment-ready CI/CD pipelines from sprint one.</p>
                </div>

                <div class="methodology-step">
                    <div class="step-number">4</div>
                    <h3>Continuous Value Delivery</h3>
                    <p>Automated deployment, real-time observability, and measurable KPIs. Systems are built for autonomous operation with enterprise-grade monitoring and governance.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Results Summary -->
    <section id="results-summary" class="section results-summary">
        <div class="container">
            <div class="section-header centered">
                <span class="section-label">Enterprise Value Creation</span>
                <h2 class="section-title">Measurable Impact at Scale</h2>
            </div>

            <div class="results-grid">
                <div class="result-card">
                    <div class="result-icon">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"></path>
                        </svg>
                    </div>
                    <div class="result-value">95%</div>
                    <div class="result-label">Operational Cycle Reduction</div>
                    <p>Automation eliminates six-figure manual overhead</p>
                </div>

                <div class="result-card">
                    <div class="result-icon">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"></circle>
                            <polyline points="12 6 12 12 16 14"></polyline>
                        </svg>
                    </div>
                    <div class="result-value">24/7</div>
                    <div class="result-label">Autonomous Operations</div>
                    <p>Enterprise systems delivering continuous value</p>
                </div>

                <div class="result-card">
                    <div class="result-icon">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                        </svg>
                    </div>
                    <div class="result-value">100%</div>
                    <div class="result-label">Data Sovereignty</div>
                    <p>Zero vendor dependency across all platforms</p>
                </div>

                <div class="result-card">
                    <div class="result-icon">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="12" y1="1" x2="12" y2="23"></line>
                            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                        </svg>
                    </div>
                    <div class="result-value">$56B+</div>
                    <div class="result-label">Combined TAM Exposure</div>
                    <p>Across market intelligence, payments, AI governance, and content</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Call to Action -->
    <section id="portfolio-cta" class="section portfolio-cta">
        <div class="container">
            <div class="cta-content">
                <h2>Ready to Deploy Enterprise-Scale AI?</h2>
                <p>Explore investment opportunities in production-ready IP with proven market positioning</p>
                <div class="cta-buttons">
                    <a href="<?php echo esc_url(home_url('/#contact')); ?>" class="btn btn-primary">Schedule a Consultation</a>
                    <a href="<?php echo esc_url(home_url('/#investors')); ?>" class="btn btn-secondary">Investment Opportunities</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    

<?php get_footer(); ?>
